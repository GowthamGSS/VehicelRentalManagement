package vehicleRentalSystem;

import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/verify")
public class loginverification extends HttpServlet{

	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		String ml=req.getParameter("mail");
		String pwd=req.getParameter("pwd");	   
		PrintWriter pw=res.getWriter();
		HttpSession session=req.getSession();
		session.removeAttribute("user");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Gowtham7869");
			Statement stt=con.createStatement();
			ResultSet rs=stt.executeQuery("select * from vhm ");
			int fl=0;
			int fl1=0;
			
			while(rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				if(rs.getString(1).equals(ml) && rs.getString(2).equals(pwd)) {
					//pw.print("Logged in Successfully");
					session.setAttribute("user", ml);
					fl=1;
					res.sendRedirect("home.jsp");
					break;
				}
			}
			
			if(fl==0) {
				Statement stt1=con.createStatement();
				ResultSet rs1=stt.executeQuery("select * from admin ");
				while(rs1.next()) {
					System.out.println(rs1.getString(1));
					System.out.println(rs1.getString(2));
					if(rs1.getString(2).equals(ml) && rs1.getString(3).equals(pwd)) {
						//pw.print("Logged in Successfully");
						session.setAttribute("stream", stream);
						fl1=1;
						res.sendRedirect("admin.jsp");
						break;
					}
				
				}
				
				if(fl1==0) {
				pw.print("Enter valid credentials");
				res.sendRedirect("home.html");
				}
				
			}
			
			
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	
		
		
		
	}

}
